package com.example.mygeekout

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mygeekout.databinding.RankingRowBinding

class AccountAdapter(private val accounts: MutableList<Account>): RecyclerView.Adapter<AccountAdapter.RankHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RankHolder {
        return RankHolder(RankingRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: RankHolder, position: Int) {
        holder.name.text = accounts[position].nickGet()
        holder.points.text = accounts[position].points()
        holder.rank.text = (position+1).toString()
    }

    override fun getItemCount(): Int {
        return accounts.size
    }


    inner class RankHolder(binding: RankingRowBinding): RecyclerView.ViewHolder(binding.root){
        val rank: TextView = binding.rankingNumber
        val name: TextView = binding.rankNickname
        val points: TextView = binding.rankPoints
    }
}