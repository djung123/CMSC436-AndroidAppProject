package com.example.mygeekout


import android.app.ProgressDialog
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.provider.Settings.Global.getString
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import androidx.lifecycle.*
import androidx.navigation.fragment.findNavController
import com.example.mygeekout.databinding.FragmentSingleBinding
import com.google.android.gms.tasks.Task
import com.google.firebase.database.ktx.snapshots
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AccountViewModel: ViewModel(), LifecycleObserver {

    @Volatile private var AUTHINSTANCE : FirebaseAuth ?= null

    fun getAuthInstance(): FirebaseAuth {
        return AUTHINSTANCE ?: synchronized(this){

            val instance = requireNotNull(FirebaseAuth.getInstance())
            AUTHINSTANCE = instance
            instance

        }
    }

    @Volatile private var REFINSTANCE : DatabaseReference ?= null

    fun getREFInstance(): DatabaseReference {
        return REFINSTANCE ?: synchronized(this){

            val instance = FirebaseDatabase.getInstance().reference
            REFINSTANCE = instance
            instance

        }
    }

    private var _myaccount = MutableLiveData<Account?>()
    internal val myaccount: LiveData<Account?> = _myaccount

    private var _points = MutableLiveData<String>()
    internal val points: LiveData<String> = _points

    init {
        _myaccount.value = Account("","","","")
    }

    internal fun bindToActivityLifecycle(mainActivity: MainActivity) {
        mainActivity.lifecycle.addObserver(this)
    }

    fun getId(): String? {
        return _myaccount.value?.idGet()!!
    }

    fun getEmail(): String? {
        return _myaccount.value?.emailGet()!!
    }

    fun getNick(): String? {
        return _myaccount.value?.nickGet()!!
    }
    fun getPoints(): String? {
        return _myaccount.value?.points()!!
    }

    fun logout(){
        AUTHINSTANCE?.signOut()
        clearData()
    }

    //TODO: this function is not being called at all
    fun updateAccount(email: String) {
        getREFInstance().child("accounts").addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                var userAcc: Account? = null

                for (acc in snapshot.children){
                    try{
                        userAcc = acc.getValue(Account::class.java)
                    } catch (e: Exception){
                    } finally {
                        if (userAcc?.emailGet() == email){
                            _myaccount.value = userAcc
                            val str: String = userAcc.emailGet()
                            break
                        }
                    }
                }
                getREFInstance().child("accounts").removeEventListener(this)
            }
            override fun onCancelled(error: DatabaseError) { }
        })
    }

    fun updatePoints(point: Int){
        //TODO: update the current account's points and write it to the database
        _myaccount.value?.addPoints(point)
        REFINSTANCE!!.child("accounts").child(getId()!!).setValue(_myaccount.value!!)
        //_myaccount.value?.let { REFINSTANCE?.child("accounts")?.child(it.emailGet())?.setValue(_myaccount.value) }

    }

    private fun clearData(){
        val fakeAccount: Account = Account("", "", "", "")
        _myaccount.value = fakeAccount
    }





}