package com.example.mygeekout

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.mygeekout.databinding.FragmentRankBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener


class RankFragment : Fragment() {

    private lateinit var binding: FragmentRankBinding
    private lateinit var dataRef: DatabaseReference
    private lateinit var myViewModel: AccountViewModel
    private lateinit var accounts: MutableList<Account>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentRankBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        myViewModel = ViewModelProvider(requireActivity())[AccountViewModel::class.java]
        dataRef = myViewModel.getREFInstance()
        accounts = ArrayList()

        loadAccounts()

        binding.button.setOnClickListener{
            findNavController().navigate(R.id.action_rankFragment_to_homeFragment)
        }



    }

    private fun loadAccounts(){
        dataRef.child("accounts").addValueEventListener(object: ValueEventListener{
            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

            override fun onDataChange(snapshot: DataSnapshot) {
                accounts.clear()

                var tempAcc: Account? = null
                for (acc in snapshot.children){
                    try{
                        tempAcc = acc.getValue(Account::class.java)
                    }catch (e: Exception){
                        Log.e("Error", "failed to bring account")
                    }finally {
                        accounts.add(tempAcc!!)


                    }
                }
                accounts.sortByDescending { it.pointsToInt() }
                Log.e("added", accounts[0].nickGet())
                Log.e("added", accounts[1].nickGet())
                AccountAdapter(accounts).also {
                    // Set the RecyclerView to this adapter.
                    binding.recyclerView.adapter = it

                    // Setting a fixed size adapter improves performance.
                    binding.recyclerView.setHasFixedSize(false)
                    Log.e("done", "done")
                }
                dataRef.child("accounts").removeEventListener(this)
            }
        })
    }

}