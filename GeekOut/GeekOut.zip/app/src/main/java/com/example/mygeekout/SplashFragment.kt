package com.example.mygeekout

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.mygeekout.databinding.FragmentSplashBinding


class SplashFragment : Fragment() {

    private lateinit var binding: FragmentSplashBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSplashBinding.inflate(layoutInflater)

        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED

        Handler(Looper.myLooper()!!).postDelayed({

            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR

            findNavController().navigate(R.id.action_splashFragment_to_loginFragment)
        }, 4000)

        return binding.root
    }


}