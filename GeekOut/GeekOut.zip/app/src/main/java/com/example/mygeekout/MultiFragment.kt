package com.example.mygeekout

import android.app.ProgressDialog
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.mygeekout.databinding.FragmentMultiBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener

class MultiFragment : Fragment() {

    private lateinit var binding: FragmentMultiBinding
    private lateinit var connectionRef: DatabaseReference
    private lateinit var viewModel: AccountViewModel
    private lateinit var questions: MutableList<Question>
    private lateinit var usedQuestions: MutableList<Question>

    private var opponentFound: Boolean = false

    private var opponentUniqueID: String = "0"

    private var leader: String = "no"

    //waiting if player still waiting for others, or playing
    private var status: String = "playing"

    private var connectionID: String = ""

    private var qCounts: Int = 0
    private var point = 0

    private lateinit var updater: Runnable
    private var counter = 10
    private var time = 0

    //status of a question: (Leader Only Status) "still" means working on a question, "done" means leader needs to update a question
    private var onQ: String = "done"
    private var onP: String = "done"
    private var staticUpdater = ""
    private var playerRoomId = ""
    private var timerCheck = false

    private var roomUniqueID = ""


    //generating ValueEventListeners for Firebase Database
    private lateinit var questionListener: ValueEventListener
    private lateinit var pointListener: ValueEventListener


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMultiBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[AccountViewModel::class.java]
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
        connectionRef = viewModel.getREFInstance()
        binding.player1.text = viewModel.getNick()
        binding.point1.text = "0"

        questions = ArrayList()
        usedQuestions = ArrayList()

        generateQuestions(questions)
        if (questions.size != 0){
            questions.shuffle()
            Log.e("shuffle", questions[0].question)
        }

        val pDialog =  ProgressDialog(requireContext())
        pDialog.setCancelable(false)
        pDialog.setMessage("Matching Players")
        pDialog.show()

        initLs()


        connectionRef.child("rooms").addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                //check if opponent found or not. If not then look for
                if (!opponentFound){
                    //checking if there are others matching
                    if(snapshot.hasChildren()){
                        //checking all rooms if other users are also matching
                        for(rooms in snapshot.children){
                            //get room unique ID
                            val roomId: String = rooms.key.toString()
                            var playerCount: Int = rooms.childrenCount.toInt()

                            //after creating a room, waiting for others to join
                            if(status == "waiting"){
                                //if 2 means ready to start
                                if(playerCount == 2){
                                    //true when other player found to play
                                    var playerFound: Boolean = false

                                    //getting players in room
                                    for(players in rooms.children){
                                        val getPlayerUniqueID: String? = players.key.toString()

                                        var playerName: String? = null
                                        for(ppp in players.children){
                                            playerName = ppp.child("player_name").getValue(String::class.java)
                                        }

                                        //check if the room belongs to the created player
                                        if (getPlayerUniqueID == playerRoomId){
                                            playerFound = true
                                        }else if(playerFound){
                                            val getPlayer2Name: String? = players.child(players.key.toString()).child(playerName!!).getValue(String::class.java)
                                            opponentUniqueID = getPlayerUniqueID!!

                                            //set player name to the view
                                            binding.player2.text = playerName!!

                                            //assign room id
                                            connectionID = roomId
                                            opponentFound = true

                                            connectionRef.child("room_questions").child(connectionID).addValueEventListener(questionListener)
                                            connectionRef.child("points").child(connectionID).addValueEventListener(pointListener)
                                           // connectionRef.child("updater").child(connectionID).addValueEventListener(updaterListener)


                                            //hide progress dialog here
                                            if (pDialog.isShowing){
                                                pDialog.dismiss()
                                            }
                                            //once the room has made, rmv the listner from database ref
                                            connectionRef.child("rooms").removeEventListener(this)
                                        }
                                    }
                                }
                            }
                            //in case user has not created room bc there are other rooms available
                            else{
                                //checking if the room has only 1player and need more players to play then join this room
                                if(playerCount == 1){
                                    playerRoomId = System.currentTimeMillis().toString()
                                    //add player to the room
                                    rooms.child(playerRoomId).child(viewModel.getId()!!).child("player_name").ref.setValue(viewModel.getNick())

                                    //getting players
                                    for(players in rooms.children){
                                        opponentUniqueID = players.key.toString()
                                        for (ppp in players.children){
                                            val getOpponentName: String? = ppp.child("player_name").getValue(String::class.java)

                                            //setting player name to the view
                                            binding.player2.text = getOpponentName
                                        }

                                        //assigning room id
                                        connectionID = roomId
                                        opponentFound = true

                                        connectionRef.child("room_questions").child(connectionID).addValueEventListener(questionListener)
                                        connectionRef.child("points").child(connectionID).addValueEventListener(pointListener)

                                        //TODO:check if this works
                                        //hide progress dialog here
                                        if (pDialog.isShowing){
                                            pDialog.dismiss()
                                        }

                                        //once the room has made, rmv the listner from database ref
                                        connectionRef.child("rooms").removeEventListener(this)

                                        break
                                    }
                                }
                            }
                        }

                        //There were rooms but all occupied
                        //check if opponent is not found and user is not matching players anymore then create a new room
                        if(!opponentFound && status != "waiting"){
                            roomUniqueID = snapshot.ref.push().key.toString()
                            playerRoomId = System.currentTimeMillis().toString()


                            //adding the first player to the room
                            snapshot.child(roomUniqueID!!).child(playerRoomId).child(viewModel.getId()!!).child("player_name").ref.setValue(viewModel.getNick())
                            status = "waiting"
                            leader = "yes"
                        }
                    }
                    // if there is no rooms available, create a new one
                    else{
                        //unique ID for the room
                        roomUniqueID = snapshot.ref.push().key.toString()
                        playerRoomId = System.currentTimeMillis().toString()

                        //adding the first player to the room
                        snapshot.child(roomUniqueID!!).child(playerRoomId).child(viewModel.getId()!!).child("player_name").ref.setValue(viewModel.getNick())
                        status = "waiting"
                        leader = "yes"

                    }

                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })


        updater = Runnable {
            if (counter == 0){

                var updater = getString(R.string.updater, qCounts)
                staticUpdater = updater


                if (leader == "yes"){
                    connectionRef.child("room_questions").child(connectionID).child(updater).setValue("updater")
                }

                connectionRef.child("points").child(connectionID).child(playerRoomId).child("points").addListenerForSingleValueEvent(object: ValueEventListener{
                    override fun onDataChange(snapshot: DataSnapshot) {
                        point = snapshot.getValue(String::class.java)!!.toInt()
                        point += (time * 10)
                        connectionRef.child("points").child(connectionID).child(playerRoomId).child("points").setValue(point.toString())
                        time = 0
                    }

                    override fun onCancelled(error: DatabaseError) {
                        TODO("Not yet implemented")
                    }
                })
                counter = 10
            }
            with(binding.timer) {
                text = (--counter).toString()
                postDelayed(updater, 1000)
            }
        }
        setTimerEnabled(false)


        binding.let {

            it.choice1.setOnClickListener{
                updateScore()
                changeChoice(it as TextView)
            }
            it.choice2.setOnClickListener{
                updateScore()
                changeChoice(it as TextView)
            }
            it.choice3.setOnClickListener{
                updateScore()
                changeChoice(it as TextView)
            }
            it.choice4.setOnClickListener{
                updateScore()
                changeChoice(it as TextView)
            }
        }

    }



    private fun initLs(){

        questionListener = object:ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                //updating question
                if (leader == "yes" && qCounts < 10){
                    if (onQ == "done"){
                        questions.shuffle()
                        snapshot.child(qCounts.toString()).ref.setValue(questions[0])
                        usedQuestions.add(questions[0])
                        questions.removeAt(0)
                        onQ = "still"
                    }
                    //update the views
                    else if (onQ == "still"){
                        //TODO: make sure added questions are in this format or ref
                        with (binding){
                            if(!this.choice1.isEnabled){
                                this.choice1.isEnabled = true
                                this.choice1.setBackgroundResource(R.drawable.choices)
                            }
                            if(!this.choice2.isEnabled){
                                this.choice2.isEnabled = true
                                this.choice2.setBackgroundResource(R.drawable.choices)
                            }
                            if(!this.choice3.isEnabled){
                                this.choice3.isEnabled = true
                                this.choice3.setBackgroundResource(R.drawable.choices)
                            }
                            if(!this.choice4.isEnabled){
                                this.choice4.isEnabled = true
                                this.choice4.setBackgroundResource(R.drawable.choices)
                            }
                        }
                        binding.question.text = snapshot.child(qCounts.toString()).child("question").getValue(String::class.java)
                        binding.choice1.text = snapshot.child(qCounts.toString()).child("answer1").getValue(String::class.java)
                        binding.choice2.text = snapshot.child(qCounts.toString()).child("answer2").getValue(String::class.java)
                        binding.choice3.text = snapshot.child(qCounts.toString()).child("answer3").getValue(String::class.java)
                        binding.choice4.text = snapshot.child(qCounts.toString()).child("answer4").getValue(String::class.java)
                        binding.genre2.text = getString(R.string.genre, snapshot.child(qCounts.toString()).child("genre").getValue(String::class.java))
                        binding.numOfQs2.text = getString(R.string.numOfQs, (qCounts+1))


                        qCounts += 1
                        onQ = "done"

                        setTimerEnabled(true)
                        timerCheck = true
                    }
                }else if (leader == "no" && qCounts < 10){
                    if(snapshot.hasChildren()){
                        if (snapshot.hasChild(qCounts.toString())) {

                            with(binding) {
                                if (!this.choice1.isEnabled) {
                                    this.choice1.isEnabled = true
                                    this.choice1.setBackgroundResource(R.drawable.choices)
                                }
                                if (!this.choice2.isEnabled) {
                                    this.choice2.isEnabled = true
                                    this.choice2.setBackgroundResource(R.drawable.choices)
                                }
                                if (!this.choice3.isEnabled) {
                                    this.choice3.isEnabled = true
                                    this.choice3.setBackgroundResource(R.drawable.choices)
                                }
                                if (!this.choice4.isEnabled) {
                                    this.choice4.isEnabled = true
                                    this.choice4.setBackgroundResource(R.drawable.choices)
                                }

                                for (qqq in snapshot.children) {
                                    if (qqq.key.toString() == qCounts.toString()) {
                                        usedQuestions.add(qqq.getValue(Question::class.java)!!)
                                        break
                                    }
                                }

                                //TODO: Generate a question variable and use it to update views instead of loading individual data
                                binding.question.text =
                                    snapshot.child(qCounts.toString()).child("question")
                                        .getValue(String::class.java)
                                binding.choice1.text =
                                    snapshot.child(qCounts.toString()).child("answer1")
                                        .getValue(String::class.java)
                                binding.choice2.text =
                                    snapshot.child(qCounts.toString()).child("answer2")
                                        .getValue(String::class.java)
                                binding.choice3.text =
                                    snapshot.child(qCounts.toString()).child("answer3")
                                        .getValue(String::class.java)
                                binding.choice4.text =
                                    snapshot.child(qCounts.toString()).child("answer4")
                                        .getValue(String::class.java)
                                binding.genre2.text = getString(R.string.genre, snapshot.child(qCounts.toString()).child("genre").getValue(String::class.java))
                                binding.numOfQs2.text = getString(R.string.numOfQs, (qCounts+1))



                                qCounts += 1

                                setTimerEnabled(true)
                                timerCheck = true
                            }
                        }
                    }
                }else{
                    setTimerEnabled(false)
                    connectionRef.child("room_questions").child(connectionID).removeEventListener(questionListener)
                    connectionRef.child("points").child(connectionID).removeEventListener(pointListener)
                    viewModel.updatePoints(point)
                    //connectionRef.child("rooms").child(roomUniqueID).removeValue()
                    //connectionRef.child("points").child(roomUniqueID).removeValue()
                    //connectionRef.child("room_questions").child(roomUniqueID).removeValue()
                    findNavController().navigate(R.id.action_multiFragment_to_finishDialog)
                }
            }
            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        }

        pointListener = object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if (onP == "done"){
                    snapshot.child(playerRoomId).child("points").ref.setValue("0")
                    onP = "waiting"
                }else if (onP == "waiting"){
                    binding.point1.text = snapshot.child(playerRoomId).child("points").getValue(String::class.java)
                    binding.point2.text = snapshot.child(opponentUniqueID).child("points").getValue(String::class.java)

                }
            }
            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        }
    }

    private fun generateQuestions(list: MutableList<Question>){
        viewModel.getREFInstance().child("allQuestions")?.ref?.addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                list.clear()
                var question: Question? = null
                for (qs in snapshot.children){
                    question = qs.getValue(Question::class.java)
                    list.add(question!!)
                }
            }
            override fun onCancelled(error: DatabaseError) {

            }
        })
    }

    private fun setTimerEnabled(isInForeground: Boolean) {
        if (!timerCheck || !isInForeground){
            if (isInForeground) {
                counter = 10
                // Update the counter and post the mUpdater Runnable
                with(binding.timer) {
                    text = counter.toString()
                    postDelayed(updater, 1000)
                }
            } else {
                // Remove already posted Runnables to stop the ticker's updating
                counter = 10
                binding.timer.removeCallbacks(updater)
            }
        }

    }

    private fun updateScore(){

        //TODO: disable buttons once clicked and give scores to ScoreListener
        binding.let{
            it.choice1.isEnabled = false
            it.choice2.isEnabled = false
            it.choice3.isEnabled = false
            it.choice4.isEnabled = false
         }
    }

    private fun changeChoice(text: TextView){
        //TODO: check the correctness of the question and change the view accordingly
        if (text.text == usedQuestions[qCounts - 1].key) {
            text.setBackgroundResource(R.drawable.correct_choice)
            time = binding.timer.text.toString().toInt()
        }else{
            text.setBackgroundResource(R.drawable.incorrect_choice)
        }
    }

}