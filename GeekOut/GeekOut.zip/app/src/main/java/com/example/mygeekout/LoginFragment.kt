package com.example.mygeekout

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.mygeekout.databinding.FragmentLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.R


class LoginFragment : Fragment() {

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var binding: FragmentLoginBinding
    private lateinit var myViewModel: AccountViewModel
    private lateinit var dataRef : DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentLoginBinding.inflate(inflater, container, false)

        // Return the root view.
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        myViewModel = ViewModelProvider(requireActivity())[AccountViewModel::class.java]

        firebaseAuth = myViewModel.getAuthInstance()

        binding.loginButton.setOnClickListener { loginUserAccount() }
        binding.regiButton.setOnClickListener {
            findNavController().navigate(com.example.mygeekout.R.id.action_loginFragment_to_registerFragment)
        }

    }

    private fun loginUserAccount() {
        val email: String = binding.emailAddress3.text.toString()
        val pass: String = binding.password.text.toString()

        if (TextUtils.isEmpty((email))){
            Toast.makeText(
                requireContext(),
                getString(com.example.mygeekout.R.string.login_toast),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (TextUtils.isEmpty(pass)){
            Toast.makeText(
                requireContext(),
                getString(com.example.mygeekout.R.string.password_toast),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE

        binding.loginButton.isEnabled = false
        binding.loginButton.isClickable = false

        binding.regiButton.isEnabled = false
        binding.regiButton.isClickable = false

        firebaseAuth.signInWithEmailAndPassword(email, pass).addOnCompleteListener{ task ->
            binding.progressBar.visibility = View.GONE
            if (task.isSuccessful){
                Toast.makeText(
                    requireContext(),
                    getString(com.example.mygeekout.R.string.login_success_toast),
                    Toast.LENGTH_LONG
                ).show()

                //TODO: Update the account to the viewModel by loading the matching account object from the database
                myViewModel.updateAccount(email) //update the current user information in viewModel

                findNavController().navigate(com.example.mygeekout.R.id.action_loginFragment_to_homeFragment)

            }else {
                Toast.makeText(
                    requireContext(),
                    getString(com.example.mygeekout.R.string.login_fail_toast),
                    Toast.LENGTH_LONG
                ).show()

                binding.loginButton.isEnabled = true
                binding.loginButton.isClickable = true

                binding.regiButton.isEnabled = true
                binding.regiButton.isClickable = true


            }
        }
    }




}