package com.example.mygeekout

data class Question(val question: String = "", val answer1: String = "", val answer2: String = "",
                    val answer3: String = "", val answer4: String = "", val key: String = "",
                    val genre: String = "") {
    fun generateChoices(list: MutableList<String>){

    }
}