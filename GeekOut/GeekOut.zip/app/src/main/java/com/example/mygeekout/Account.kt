package com.example.mygeekout

data class Account (val id: String = "", val email: String = "", val nickName: String = "", var points: String = ""){
    fun idGet(): String {
        return id
    }
    fun emailGet(): String {
        return email
    }
    fun nickGet(): String{
        return nickName
    }
    fun addPoints(point: Int){
        var tempInt: Int = points.toInt()
        tempInt += point
        points = tempInt.toString()
    }
    fun points(): String{
        return points
    }
    fun pointsToInt(): Int{
        return points.toInt()
    }


}