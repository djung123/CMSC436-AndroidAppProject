package com.example.mygeekout;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class MyAdapter extends RecyclerView.Adapter<MyAdapter.RankViewHolder> {
    Context context;
    ArrayList<Account> accounts;

    public MyAdapter(Context context, ArrayList<Account> accounts){
        this.context = context;
        this.accounts = accounts;
    }

    @NonNull
    @Override
    public MyAdapter.RankViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.ranking_row, parent, false);
        return new MyAdapter.RankViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.RankViewHolder holder, int position) {
        holder.name.setText(accounts.get(position).getNickName());
        holder.points.setText(accounts.get(position).getPoints());
        holder.ranking.setText(String.valueOf((position+1)));
    }

    @Override
    public int getItemCount() {
        return accounts.size();
    }

    public static class RankViewHolder extends RecyclerView.ViewHolder{

        TextView ranking;
        TextView name;
        TextView points;


        public RankViewHolder(@NonNull View itemView) {
            super(itemView);
            ranking = itemView.findViewById(R.id.ranking_number);
            name = itemView.findViewById(R.id.rank_nickname);
            points = itemView.findViewById(R.id.rank_points);
        }
    }
}
