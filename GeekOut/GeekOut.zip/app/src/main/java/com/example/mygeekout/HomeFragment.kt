package com.example.mygeekout

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.mygeekout.databinding.FragmentHomeBinding
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var viewModel: AccountViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        viewModel = ViewModelProvider(requireActivity())[AccountViewModel::class.java]

        viewModel.myaccount.observe(viewLifecycleOwner){
            binding.accountNickname.text = getString(com.example.mygeekout.R.string.home_info, viewModel.getNick())
            binding.points.text = getString(com.example.mygeekout.R.string.home_points, viewModel.getPoints())
        }

        //TODO: Check why not updating
        //binding.accountNickname.text = getString(com.example.mygeekout.R.string.home_info, viewModel.getNick())
        //binding.points.text = getString(com.example.mygeekout.R.string.home_points, viewModel.getPoints())


        binding.logoutButton.setOnClickListener{
            viewModel.logout()
            Toast.makeText(
                requireContext(),
                "Successfully Logged Out",
                Toast.LENGTH_LONG
            )
            findNavController().navigate(R.id.action_homeFragment_to_loginFragment)
        }

        binding.rankButton?.setOnClickListener{
            findNavController().navigate(R.id.action_homeFragment_to_rankFragment)
        }

        binding.single.setOnClickListener{
            findNavController().navigate(R.id.action_homeFragment_to_singleFragment)
        }

        binding.multi.setOnClickListener{
            Toast.makeText(
                requireContext(),
                "Looking for players",
                Toast.LENGTH_LONG
            )
            findNavController().navigate(R.id.action_homeFragment_to_multiFragment)
        }
    }


    override fun onAttach(context: Context) {
        super.onAttach(context)
        val callback: OnBackPressedCallback = object: OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                //TODO: Add dialog asking you want to logout or not
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(this, callback)
    }




}