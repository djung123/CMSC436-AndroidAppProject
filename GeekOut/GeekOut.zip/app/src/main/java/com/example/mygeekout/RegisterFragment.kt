package com.example.mygeekout

import android.os.Bundle
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.mygeekout.databinding.FragmentRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.R

class RegisterFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var ref: DatabaseReference
    private lateinit var binding: FragmentRegisterBinding
    private lateinit var viewModel: AccountViewModel
    private var validator = Validators()



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRegisterBinding.inflate(layoutInflater)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[AccountViewModel::class.java]
        auth = viewModel.getAuthInstance()
        ref = viewModel.getREFInstance()

        binding.registerButton.setOnClickListener { registerNewUser() }
        binding.logButton.setOnClickListener {
            findNavController().navigate(com.example.mygeekout.R.id.action_registerFragment_to_loginFragment)
        }
    }

    private fun registerNewUser() {
        val email: String = binding.emailAddress3.text.toString()
        val pass: String = binding.password.text.toString()
        val nickname: String = binding.editTextTextPersonName.text.toString()

        if (!validator.validEmail(email)){
            Toast.makeText(
                requireContext(),
                getString(com.example.mygeekout.R.string.invalid_email),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (TextUtils.isEmpty(nickname)){
            Toast.makeText(
                requireContext(),
                getString(com.example.mygeekout.R.string.nickname),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (!validator.validPassword(pass)){
            Toast.makeText(
                requireContext(),
                getString(com.example.mygeekout.R.string.invalid_password),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        binding.progressBar2.visibility = View.VISIBLE

        binding.logButton.isEnabled = false
        binding.logButton.isClickable = false

        binding.registerButton.isEnabled = false
        binding.registerButton.isClickable = false

        auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener{task ->
            binding.progressBar2.visibility =View.GONE
            if (task.isSuccessful) {
                Toast.makeText(
                    requireContext(),
                    getString(com.example.mygeekout.R.string.register_success_string),
                    Toast.LENGTH_LONG
                ).show()

                //TODO: make account object and save it to the base
                val id = ref.child("account").push().key
                val account = Account(id!!, email, nickname, "0")
                ref.child("accounts").child(id).setValue(account)


                findNavController().navigate(com.example.mygeekout.R.id.action_registerFragment_to_loginFragment)

            }else {
                Toast.makeText(
                    requireContext(),
                    getString(com.example.mygeekout.R.string.register_failed_string),
                    Toast.LENGTH_LONG
                ).show()

                binding.logButton.isEnabled = true
                binding.logButton.isClickable = true

                binding.registerButton.isEnabled = true
                binding.registerButton.isClickable = true
            }
        }

    }


}