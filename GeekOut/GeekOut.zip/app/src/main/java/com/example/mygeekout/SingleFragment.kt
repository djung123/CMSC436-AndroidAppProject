package com.example.mygeekout

import android.app.ProgressDialog
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable.Orientation
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.mygeekout.databinding.FragmentMultiBinding
import com.example.mygeekout.databinding.FragmentSingleBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.delay


class SingleFragment : Fragment() {

    private lateinit var binding: FragmentSingleBinding
    private lateinit var connectionRef: DatabaseReference
    private lateinit var viewModel: AccountViewModel
    private lateinit var questions: MutableList<Question>
    private lateinit var usedQuestions: MutableList<Question>

    private var timerCheck = false

    private lateinit var questionListener: ValueEventListener
    private lateinit var pointListener: ValueEventListener
    private var point = 0

    private var roomId = ""

    private var qCounts: Int = 0
    private var onQ: String = "done"
    private var onP: String = "done"

    private lateinit var updater: Runnable
    private var counter = 10


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSingleBinding.inflate(layoutInflater)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[AccountViewModel::class.java]
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED


        connectionRef = viewModel.getREFInstance()
        binding.player1.text = viewModel.getNick()
        binding.point1.text = "0"

        questions = ArrayList()
        usedQuestions = ArrayList()

        generateQuestions(questions)
        if (questions.size != 0){
            questions.shuffle()
            Log.e("shuffle", questions[0].question)
        }

        val pDialog =  ProgressDialog(requireContext())
        pDialog.setCancelable(false)
        pDialog.setMessage("Loading...")
        pDialog.show()

        initLs()

        questions.shuffle()
        connectionRef.child("singleRooms").addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val roomUniqueID = snapshot.ref.push().key
                roomId = roomUniqueID!!

                //adding the player to the room
                snapshot.child(roomUniqueID!!).child(viewModel.getId()!!).child("player_name").ref.setValue(viewModel.getNick())
                connectionRef.child("room_questions").child(roomUniqueID).addValueEventListener(questionListener)
                connectionRef.child("points").child(roomUniqueID).addValueEventListener(pointListener)
                connectionRef.child("singleRooms").removeEventListener(this)

                if (pDialog.isShowing){
                    pDialog.dismiss()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
        //savedInstanceState?.let { counter = it.getInt(COUNTER_KEY) }
        updater = Runnable {
            if (counter == 0){

                connectionRef.child("room_questions").child(roomId).child(System.currentTimeMillis().toString()).setValue("updater")

                counter = 10
            }
            with(binding.timer) {
                text = (--counter).toString()
                postDelayed(updater, 1000)
            }
        }
        setTimerEnabled(false)

        binding.let {
            it.choice1.setOnClickListener{
                counter = 10
                updateScore()
                changeChoice(it as TextView)
            }
            it.choice2.setOnClickListener{
                counter = 10
                updateScore()
                changeChoice(it as TextView)
            }
            it.choice3.setOnClickListener{
                counter = 10
                updateScore()
                changeChoice(it as TextView)
            }
            it.choice4.setOnClickListener{
                counter = 10
                updateScore()
                changeChoice(it as TextView)
            }
        }


    }


    private fun initLs(){
        questionListener = object:ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                //updating question
                if (qCounts < 10){
                    if (onQ == "done"){
                        questions.shuffle()
                        snapshot.child(qCounts.toString()).ref.setValue(questions[0])
                        usedQuestions.add(questions[0])
                        questions.removeAt(0)
                        onQ = "still"
                    }
                    //update the views
                    else if (onQ == "still"){
                        //TODO: make sure added questions are in this format or
                        with(binding){
                            if(!this.choice1.isEnabled){
                                this.choice1.isEnabled = true
                                this.choice1.setBackgroundResource(R.drawable.choices)
                            }
                            if(!this.choice2.isEnabled){
                                this.choice2.isEnabled = true
                                this.choice2.setBackgroundResource(R.drawable.choices)
                            }
                            if(!this.choice3.isEnabled){
                                this.choice3.isEnabled = true
                                this.choice3.setBackgroundResource(R.drawable.choices)
                            }
                            if(!this.choice4.isEnabled){
                                this.choice4.isEnabled = true
                                this.choice4.setBackgroundResource(R.drawable.choices)
                            }
                        }
                        //counter = 10
                        binding.question.text = snapshot.child(qCounts.toString()).child("question").getValue(String::class.java)
                        binding.choice1.text = snapshot.child(qCounts.toString()).child("answer1").getValue(String::class.java)
                        binding.choice2.text = snapshot.child(qCounts.toString()).child("answer2").getValue(String::class.java)
                        binding.choice3.text = snapshot.child(qCounts.toString()).child("answer3").getValue(String::class.java)
                        binding.choice4.text = snapshot.child(qCounts.toString()).child("answer4").getValue(String::class.java)
                        binding.genre.text = getString(R.string.genre, snapshot.child(qCounts.toString()).child("genre").getValue(String::class.java))
                        binding.numOfQs.text = getString(R.string.numOfQs, (qCounts+1))

                        qCounts += 1
                        onQ = "done"


                        setTimerEnabled(true)
                        timerCheck = true


                    }
                }else{
                    //TODO:: after 10questions, finish the game and return to home fragment, update scores to the account
                    setTimerEnabled(false)
                    connectionRef.child("room_questions").child(roomId).removeEventListener(questionListener)
                    connectionRef.child("points").child(roomId).removeEventListener(pointListener)
                    viewModel.updatePoints(point)

                    findNavController().navigate(R.id.action_singleFragment_to_finDialog)

                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        }

        pointListener = object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if (onP == "done"){
                    snapshot.child(viewModel.getId()!!).child("points").ref.setValue("0")
                    onP = "waiting"
                }else if (onP == "waiting"){
                    binding.point1.text = snapshot.child(viewModel.getId()!!).child("points").getValue(String::class.java)
                }
            }
            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        }
    }


    private fun generateQuestions(list: MutableList<Question>){
        viewModel.getREFInstance().child("allQuestions")?.ref?.addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                list.clear()
                var question: Question? = null
                for (qs in snapshot.children){
                    question = qs.getValue(Question::class.java)
                    list.add(question!!)
                }
            }
            override fun onCancelled(error: DatabaseError) {

            }
        })
    }

    private fun setTimerEnabled(isInForeground: Boolean) {
        if (!timerCheck || !isInForeground){
            if (isInForeground) {
                counter = 10
                // Update the counter and post the mUpdater Runnable
                with(binding.timer) {
                    text = counter.toString()
                    postDelayed(updater, 1000)
                }
            } else {
                // Remove already posted Runnables to stop the ticker's updating
                counter = 10
                binding.timer.removeCallbacks(updater)
            }
        }

    }

    private fun updateScore(){
        Handler(Looper.myLooper()!!).postDelayed({
        }, 1000)
        //TODO: disable buttons once clicked and give scores to ScoreListener
        binding.let{
            it.choice1.isEnabled = false
            it.choice2.isEnabled = false
            it.choice3.isEnabled = false
            it.choice4.isEnabled = false
            //setTimerEnabled(false)

        }
    }

    private fun changeChoice(text: TextView){
        //TODO: check the correctness of the question and change the view accordingly
        if (text.text == usedQuestions[qCounts - 1].key) {
            text.setBackgroundResource(R.drawable.correct_choice)
            var updater = getString(R.string.updater, qCounts)

            connectionRef.child("room_questions").child(roomId).child(updater).setValue("updater")

            connectionRef.child("points").child(roomId).child(viewModel.getId()!!).child("points").addListenerForSingleValueEvent(object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    point = snapshot.getValue(String::class.java)!!.toInt()
                    point += (binding.timer.text.toString().toInt() * 10)
                    connectionRef.child("points").child(roomId).child(viewModel.getId()!!).child("points").setValue(point.toString())
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })

        }else{
            text.setBackgroundResource(R.drawable.incorrect_choice)
            var updater = getString(R.string.updater, qCounts)

            connectionRef.child("room_questions").child(roomId).child(updater).setValue("updater")
        }
    }


}