package com.example.mygeekout

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs

class FinDialog : DialogFragment() {


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return AlertDialog.Builder(requireContext())
            // Set the message to the passed navigation message argument.
            .setMessage("Game Finished!!")

            // Prevent back button from cancelling this dialog.
            .setCancelable(false)

            // Set up positive Button.
            .setPositiveButton("Okay") { _, _ ->
                // Set a positive result in the viewModel.
                findNavController().navigate(R.id.action_finishDialog_to_homeFragment)
            }
            // Calling create generates the AlertDialog.
            .create()
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        findNavController().navigate(R.id.action_finishDialog_to_homeFragment)

    }
}